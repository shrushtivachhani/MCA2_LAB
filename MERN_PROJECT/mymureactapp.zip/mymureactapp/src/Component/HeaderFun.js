import React from 'react'

function HeaderFun() {
  return (
    <div>
        <h1>Header Function</h1>
        <p>This is Header Function</p>
    </div>
  )
}
export default HeaderFun