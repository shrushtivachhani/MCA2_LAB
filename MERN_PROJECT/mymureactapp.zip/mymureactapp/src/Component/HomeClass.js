import React from 'react'

class HomeClass extends React.Component {
    constructor(props) {
        super(props)
        this.state = {}
    }
    render() { 
        return ( <div>
            <h1>HomeClass</h1>
            <p>This is HomeClass Page</p>
        </div> );
    }
}
 
export default HomeClass
