import React from 'react'

function AboutUsFun() {
  return (
    <div>
        <h1>AboutUs Function</h1>
        <p>This is AboutUs Function</p>
    </div>
  )
}
export default AboutUsFun