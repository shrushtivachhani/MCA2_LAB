import React from 'react'

function FooterFun() {
  return (
    <div>
        <h1>Footer Function</h1>
        <p>This is Footer Function</p>
    </div>
  )
}

export default FooterFun